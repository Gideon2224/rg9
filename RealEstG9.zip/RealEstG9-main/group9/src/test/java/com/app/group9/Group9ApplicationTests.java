package com.app.group9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group9ApplicationTests {

    @Test
    void contextLoads() {
    }

}
